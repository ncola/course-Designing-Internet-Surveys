<!DOCTYPE html>
<html lang="pl-PL">
<head>
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=PT+Serif&family=Playfair+Display&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="ankietacss.css">
</head>
<body>



	<div id="container">
	
		<div id="title"> Work-life balance </div>
		<div id="info"> 
			Jesteśmy studentkami drugiego roku Analityki Gospodarczej na Uniwersytecie Ekonomicznym w Katowicach. Przeprowadzamy ankietę, która ma na celu zaanalizowanie poziomiu równowagi pomiędzy życiem i pracą wśród Polaków. Skierowana jest do osób pracujących. Jej wypełnienie nie powinno zająć dłużej niż 5 minut.		
		</div>
		
		
		<div id="content">
			<center>	
			Dziękujemy za wypełnienie ankiety. 
			</center>
			<br><br>
		</div>
			


	</div>
	


</body>
</html>